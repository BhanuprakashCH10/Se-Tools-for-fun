import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    const fileTypeToSong: { [key: string]: string } = {
        javascript: 'Lo-fi jazz.mp3',
        python: 'Calm piano.mp3',
        html: 'Ambient vibes.mp3',
        css: 'Synthwave beat.mp3',
        typescript: 'Chillhop tune.mp3'
    };

    vscode.workspace.onDidOpenTextDocument((document) => {
        const lang = document.languageId;

        if (fileTypeToSong[lang]) {
            const song = fileTypeToSong[lang];

            vscode.window.showInformationMessage(`🎶 Playing: ${song}`);
        }
    });
}

export function deactivate() {}
