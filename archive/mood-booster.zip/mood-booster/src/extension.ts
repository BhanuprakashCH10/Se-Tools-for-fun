import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    // Define the moods
    const moods = ['Happy', 'Sad', 'Excited', 'Stressed', 'Relaxed'] as const;

    // Define the quotes for each mood
    const quotes = {
        Happy: [
            "Keep smiling, because life is a beautiful thing and there's so much to smile about.",
            "Happiness depends upon ourselves.",
            "The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well."
        ],
        Sad: [
            "Tears come from the heart and not from the brain.",
            "It's okay to not be okay.",
            "Sadness flies away on the wings of time."
        ],
        Excited: [
            "Excitement is the best remedy for fear.",
            "The best way to predict the future is to create it.",
            "Stay excited, you have the power to make things happen!"
        ],
        Stressed: [
            "Inhale, exhale. Take it one step at a time.",
            "Sometimes the most productive thing you can do is relax.",
            "Stress is caused by being 'here' but wanting to be 'there'."
        ],
        Relaxed: [
            "Relaxation is the key to a healthy mind and body.",
            "Take a deep breath and let go of the stress.",
            "Peace begins with a smile."
        ]
    };

    // Function to prompt for the mood and show a random quote
    async function promptMood() {
        const selectedMood = await vscode.window.showQuickPick(moods, {
            placeHolder: 'How are you feeling?'
        });

        if (!selectedMood) {
            vscode.window.showInformationMessage('You did not select a mood.');
            return;
        }

        // Cast selectedMood to a specific key of the quotes object
        const moodQuotes = quotes[selectedMood as keyof typeof quotes];

        // Randomly pick a quote based on the selected mood
        const randomQuote = moodQuotes[Math.floor(Math.random() * moodQuotes.length)];

        // Show the random quote to the user
        vscode.window.showInformationMessage(randomQuote);
    }

    // Set the timer to show the prompt every 10 seconds
    setInterval(() => {
        promptMood();
    }, 900000);  // 10 seconds = 10000 milliseconds

    // Optionally, trigger the prompt immediately on startup (first time)
    promptMood();
}

export function deactivate() {}
