# Detect-Java-Code-Smell README

This extension will check code smells. 

## Release Notes

Nothing to say

### 1.0.0

Initial release