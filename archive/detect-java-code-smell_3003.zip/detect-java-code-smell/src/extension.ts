import * as vscode from 'vscode';
import { exec } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';


let panel: vscode.WebviewPanel | undefined;
let totalCodeSmell: string | undefined = "";
let checkboxHtml: string | undefined = "";
let tableheader = `<tr><th>FileName</th><th>Line #</th><th>Observations</th></tr>`;
let tableRows: string | undefined = "";
let rulesets: string | undefined = "";
let savedSelections: string[] | undefined = undefined;
let processingStatus: string | undefined = "";

export function activate(context: vscode.ExtensionContext) {

    let javaCodeSmellAnalyzer = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    javaCodeSmellAnalyzer.text = `$(play) Codesmell`;
    javaCodeSmellAnalyzer.tooltip = "Analyze Java Code Smell";
    javaCodeSmellAnalyzer.command = "extension.analyzeJavaCodeSmell";
    javaCodeSmellAnalyzer.show();

  



    let checkboxinput = vscode.commands.registerCommand('extension.analyzeJavaCodeSmell', () => {
    // If panel already exists, reveal it and return
    if (panel) {
        panel.reveal(vscode.ViewColumn.One);       
    }
    else{
        panel = vscode.window.createWebviewPanel(
            'apiResponse', 'API Response', vscode.ViewColumn.One, { enableScripts: true });
    }

    
    rulesets = getPMDOptions(context);
    generateTableHtml(context, "");



    // Handle messages from the WebView
    panel.webview.onDidReceiveMessage(
        message => {
            if (message.command === 'run') {
                tableRows = "";
                const workspaceState = context.workspaceState;
                workspaceState.update('selectedOptions', message.selected);
                const selectedWithValues = message.selected.map((key: string) => `${key},`);
                rulesets = getPMDOptions(context);
                totalCodeSmell = "";
                showCodeSmell(context);
            }
        },
        undefined,
        context.subscriptions
    );
        // Handle webview disposal (when closed)
        panel.onDidDispose(() => {
            panel = undefined; // Reset the reference
        }, null, context.subscriptions);
    });

    context.subscriptions.push(javaCodeSmellAnalyzer, checkboxinput);
}


export function deactivate() {}

async function showCodeSmell(context: vscode.ExtensionContext){

    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) {
        vscode.window.showInformationMessage('No workspace found!');
        return 0;
    }        
    const folderPath = workspaceFolders[0].uri.fsPath;

    await callAllFiles(context, folderPath);

    


}


async function callAllFiles(context: vscode.ExtensionContext, dirPath: string) {
    let totalLines = 0;

    processingStatus = "Processing Started...";
    vscode.window.showInformationMessage(processingStatus);
    tableRows = "";


    rulesets = getPMDOptions(context);
    if (rulesets.length < 1){
        tableRows = "";
        generateTableHtml(context, "");
        processingStatus = "No options selected";
        vscode.window.showInformationMessage(processingStatus);
        return;
    }

    // Recursively read the directory and its files
    const files = await readDir(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);

        // If it's a directory, call the function recursively
        const stat = fs.statSync(filePath);
        if (stat.isDirectory()) {
            await callAllFiles(context, filePath);
        } 
        else if (isCodeFile(filePath)) {
            await CheckCodeSmell(context, filePath);
        }
    }

}



async function CheckCodeSmell(context: vscode.ExtensionContext, filePath: string) {

    const pmdPath = 'pmd'; 


    let outputtext = "";
    let issues: string[] = [];
    const command = `${pmdPath} check -d ${filePath} -R ${rulesets} -f text`;
    //vscode.window.showInformationMessage(command);
        exec(command, (error, outputtext, stderr) => {
            if (error) {
                if (!stderr.includes ('[WARN]')) {
                vscode.window.showErrorMessage(`PMD execution failed: ${stderr}`);
                processingStatus = "Unable to process. Please check pmd guidelines.";
                vscode.window.showInformationMessage(processingStatus);
                }
            }
            if (outputtext.length > 0)
            {
              //  totalCodeSmell = totalCodeSmell + outputtext;
                totalCodeSmell = outputtext;
                processingStatus = "Processing Completed";        
                vscode.window.showInformationMessage(processingStatus);        
                if(totalCodeSmell.length > 0){

                    generateTableHtml(context, filePath);
                    const lines = totalCodeSmell.split('\n');
                    // Set the HTML content for the Webview

                }
                issues =  totalCodeSmell.split('\n');             
            }
            if (issues.length === 0) {
                processingStatus = "Processing Completed. No code smell detected.";
                tableRows = "";
                generateTableHtml(context, "");
                vscode.window.showInformationMessage(processingStatus);
            } 
        });
            
 }

async function generateTableHtml(context: vscode.ExtensionContext, filepath: string) {
    const rows = (totalCodeSmell ?? "").trim().split('\n').map(line => line.split(/:+/)); // Splits by :
    tableRows = tableRows + rows.map(row => {
        let col1 = row.length > 0 ? row[0] : "";
        let col2 = row.length > 2 ? row[1] : "";
        let col3 = row.length > 2 ? row[2] : "";
        let col4 = row.length > 2 ? row[3] : "";
        let col5 = row.length > 2 ? row[4] : "";
        if((col1.length > 0) && (col5.length === 0))
        {
            col5 = col1;
            col1 = filepath;
        }

        return `<tr><td>${col1}${col2}</td><td>${col3}</td><td>${col5}</td></tr>`;
    }).join('');

    if (panel) {                        
        panel.reveal(vscode.ViewColumn.One);      
    } else {
        panel = vscode.window.createWebviewPanel('apiResponse', 'API Response', vscode.ViewColumn.One, { enableScripts: true });
    }
    panel.webview.html = getWebviewContent(context);
}

// Define checkboxes with corresponding values
const optionValues: { [key: string]: string } = {
    "Best Practices": "category/java/bestpractices.xml",
    "Code Style": "category/java/codestyle.xml",
    "Design": "category/java/design.xml",
    "Documentation": "category/java/documentation.xml",
    "Default": "rulesets/java/quickstart.xml",
    "Error Prone": "category/java/errorprone.xml",
    "Multithread":  "category/java/multithreading.xml",
    "Performance": "category/java/performance.xml",
    "Security": "category/java/security.xml"

};

function getPMDOptions(context: vscode.ExtensionContext): string {
    const workspaceState = context.workspaceState;
    savedSelections = workspaceState.get<string[]>('selectedOptions', []);
    const selectedWithValues = savedSelections.map((key: string) => `${optionValues[key] || 'Unknown Value'},`);

    checkboxHtml = Object.keys(optionValues).map(option => {
        const checked = (savedSelections || []).includes(option) ? 'checked' : '';
        return `<label><input type="checkbox" value="${option}" ${checked}> ${option}</label><br>`;
    }).join('');

    return selectedWithValues.join('');
}

function getWebviewContent(context: vscode.ExtensionContext){
    return `<!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; padding: 10px; background-color: black; color: white; display: flex; }
            .left-panel, .right-panel { padding: 4px; }
            .left-panel { width: 15%; float: left; height: 73vh; border-right: 1px solid grey; display: flex; flex-direction: column; }
            .right-panel { width: 85%; position: relative; padding: 1px; display: flex; flex-direction: column; align-items: center; }
            .checkboxes { padding: 10px; }
            .checkbox-group { margin-bottom: 15px; }
            button { padding: 8px 15px; background: #007acc; color: white; border: none; cursor: pointer; }
            button:hover { background: #005f99; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid white; padding: 6px; text-align: left; }
            th { font-size: 20px; color: green; background-color: black; } /* Yellow text on black background */
        </style>
    </head>
    <body>
        <div class="left-panel">
            <div class="checkboxes">
                <h3>Select Options:</h3>
                <div class="checkbox-group">${checkboxHtml}</div>
                <button onclick="invokeCodeSmellCheck()">Analyse Code</button>
            </div>
        </div>
        <div class="right-panel">
                <h3>Code Smell Analysis</h3>
                <table>
                <tr><th>${tableheader}</th></tr>
                ${tableRows}
                </table>
        </div>

        <script>
            const vscode = acquireVsCodeApi();
            function invokeCodeSmellCheck(){
                const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
                const selectedValues = Array.from(checkboxes).map(cb => cb.value);
                vscode.postMessage({ command: 'run', selected: selectedValues});
            }
        </script>
    </body>
    </html>`;
}

async function readDir(dirPath: string): Promise<string[]> {
    return new Promise((resolve, reject) => {
        fs.readdir(dirPath, (err, files) => {
            if (err) {
                reject(err);
            } else {
                resolve(files);
            }
        });
    });
}

function isCodeFile(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return ['.js', '.ts', '.html', '.css', '.cpp', '.java', '.py', '.dart', '.c'].includes(ext);
}