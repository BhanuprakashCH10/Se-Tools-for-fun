# bugcount README

"Compilation Errors": Compile and show the code compilation error progress over past 20 compilations. 
"Retrieve Compilation Details" : You can also retrieve the past compilation errors without compiling.
"Clear Compilation Details": Reset the compilation history, so that tracking compilation errors will start from again.

## Release Notes

### 0.0.1

Initial release of compilation error



