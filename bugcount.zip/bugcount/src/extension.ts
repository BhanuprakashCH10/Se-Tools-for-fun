import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';


let tableheader = `<tr><th>Date</th><th>LOC</th><th>Errors</th><th>Avg (Err/LOC)</th><th>Momentum</th></tr>`;
let tableRows: string | undefined = "";
let analysedData: string | undefined = "";
let panel: vscode.WebviewPanel | undefined;

export function activate(context: vscode.ExtensionContext) {

    let compileCode = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    compileCode.text = `$(play) Compile`;
    compileCode.tooltip = "Show coding efficiency through Compilation errors";
    compileCode.command = "extension.countCompilationDetails";
    compileCode.show();


    if (panel) {
        panel.reveal(vscode.ViewColumn.One);       
    }
    else{
        panel = vscode.window.createWebviewPanel('apiResponse', 'API Response', vscode.ViewColumn.One, { enableScripts: true });
    }

    // detect the termination of degub/compilation 
    vscode.debug.onDidTerminateDebugSession( async (session) => {

        let totalErrors = await storeCompilationDetails(context);
        if (totalErrors > 0) {

            displayCompilationHistory(context);
        }


    });

    // Register the command to count lines of code and compilation errors
    let disposable = vscode.commands.registerCommand('extension.countCompilationDetails', async  () => {

            let totalErrors = await storeCompilationDetails(context);
            if (totalErrors > 0) {
                displayCompilationHistory(context);
            }

    });

    context.subscriptions.push(compileCode, disposable);

	// Register the command to clear the workspaceState for compilationData
	let clearDisposable = vscode.commands.registerCommand('extension.clearSpecificWorkspaceState', () => {
        // Clear a specific workspaceState key
        context.workspaceState.update('compilationData', []); 
      //  storedData = [];
      //  storedData.length = 0;

        vscode.window.showInformationMessage(`Workspace state for 'compilationData' has been cleared.`);
    });

	context.subscriptions.push(clearDisposable);

    // Register the command to retrieve and display the last 20 compilation details
    let retrieveDisposable = vscode.commands.registerCommand('extension.retrieveLastCompilationDetails', () => {

        displayCompilationHistory(context);

    });

    context.subscriptions.push(retrieveDisposable);

    // Event listener for when a debugging session ends
    const buildTaskListener = vscode.tasks.onDidEndTask(async (event) => {
        if (event.execution.task.name === 'build') { // Check if it's a build task (you can customize task name)
            const finishTime = new Date().toLocaleString(); // Get the current date and time
            vscode.window.showInformationMessage(`Build completion time : ${finishTime}`);
        }
    });

    context.subscriptions.push(buildTaskListener);

}

export function deactivate() {}

interface CompilationDetails {
    lineCount: number;
    errorCount: number;
    errorAvg: number;
    compileDate: string;
    progress: string;
    newline: string;
}

async function generateTableHtml(context: vscode.ExtensionContext) {

    const rows = (analysedData ?? "").trim().split('\n').map(line => line.split(/,+/)); // Splits by :
    tableRows = tableRows + rows.map(row => {
        let col1 = row.length > 0 ? row[0] : "";
        let col2 = row.length > 2 ? row[1] : "";
        let col3 = row.length > 2 ? row[2] : "";
        let col4 = row.length > 2 ? row[3] : "";
        let col5 = row.length > 2 ? row[4] : "";
        let col6 = row.length > 2 ? row[5] : "";
        return `<tr><td>${col4} ${col5}</td><td>${col1}</td><td>${col2}</td><td>${col3}</td><td>${col6}</td></tr>`;
    }).join('');

  //  panel.webview.html = getWebviewContent(context);
}

async function storeCompilationDetails(context: vscode.ExtensionContext): Promise<number> {
    let storedData: CompilationDetails[] = context.workspaceState.get<CompilationDetails[]>('compilationData', []) || [];

    if (!Array.isArray(storedData)) {
        context.workspaceState.update('compilationData', []); // Initialize as an empty array if undefined or incorrect type
    }

	const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showInformationMessage('No workspace found!');
            return 0;
        }

        const folderPath = workspaceFolders[0].uri.fsPath;

        const lineCount = await countLinesOfCode(folderPath);

        // Step 2: Count compilation errors in the workspace
        const errorCount = countCompilationErrors();
        let progress = "";

        if(errorCount !== -1){

            let errorAvg = (errorCount/lineCount) * 100;
            errorAvg = parseFloat(errorAvg.toFixed(2));

            // Step 3: Get the current date and time of compilation
            const compileDate = new Date().toLocaleString();

            if (storedData.length > 0){
                if (Number(JSON.stringify(storedData[0].errorAvg)) > errorAvg){
                    progress = "👍";
                }
                else if (Number(JSON.stringify(storedData[0].errorAvg)) === errorAvg){
                    progress = "👍=👍";
                }
                else{
                    progress = "👎";
                }
            }
            else{
                progress = "😊";
            }

            if (lineCount > 0) {
                // Step 4: Create the new compilation data entry
                const newCompilationData: CompilationDetails = {
                    lineCount,
                    errorCount,
                    errorAvg,
                    compileDate,
                    progress,
                    newline: "\n"
                };
    

                if (storedData.length > 19) {
                    storedData.pop(); // Remove the first (oldest) entry if we have more than 20
                }
                // Step 5: Add the new entry to the stored data (keeping only the last 20 entries)
                // Push new value to the front of the array (stack behavior)
                context.workspaceState.update('compilationData', []); 
                await context.workspaceState.update('compilationData', undefined);
                await context.workspaceState.update('storedSelections', undefined);
                await context.workspaceState.update('lastSaved', undefined);
                storedData.unshift(newCompilationData);
               // vscode.window.showInformationMessage(JSON.stringify(storedData));
    
                // Store the updated compilation data back into workspaceState
                context.workspaceState.update('compilationData', storedData);
            }   
   
        }
        else {
            vscode.window.showInformationMessage(`Vscode is Busy. Please rerun after vscode is ready`);
        }

        return storedData.length;

}

async function displayCompilationHistory(context: vscode.ExtensionContext) {


    const storedCompilationData = context.workspaceState.get<CompilationDetails[]>('compilationData', []);
    if (storedCompilationData.length === 0) {
        vscode.window.showInformationMessage('No compilation data available.');
        return;
    }

    
    // Show the last 20 compilation details (or all if fewer than 20)
    let detailsMessage = storedCompilationData
        .map((data, index) => `${data.lineCount}, ${data.errorCount}, ${data.errorAvg}, ${data.compileDate}, ${data.progress}, ${data.newline}`)
        .join("\n");
    
    tableRows = "";
    analysedData = detailsMessage;
    generateTableHtml(context);

   // vscode.window.showInformationMessage(`Last Compilation Details:\n${detailsMessage}`);

    // Create a new Webview panel
    if (panel) {
        panel.reveal(vscode.ViewColumn.One);       
    }
    else{
        panel = vscode.window.createWebviewPanel(
            'apiResponse', 'API Response', vscode.ViewColumn.One, { enableScripts: true });
    }

    // Set the HTML content for the Webview
    panel.webview.html = getWebviewContent(detailsMessage);

    // Optionally, you can listen to Webview events, like on close or on message
         // Handle webview disposal (when closed)
         panel.onDidDispose(() => {
            panel = undefined; // Reset the reference
        }, null, context.subscriptions);
    /*
    vscode.window.showInformationMessage(`Last Compilation Details:\n${detailsMessage}`, 'OK').then((selection) => {
        if (selection === 'OK') {
            // The "OK" button was clicked, the message will be closed automatically
            console.log("OK button clicked");
        }
    });
    */


}


// Function to count the compilation errors in the workspace
function countCompilationErrors(): number {

    let diagnostics: [vscode.Uri, vscode.Diagnostic[]][] = [];
    // Listen for when an editor becomes active and then check diagnostics


    //    if (vscode.window.activeTextEditor) {
           diagnostics = vscode.languages.getDiagnostics();   
           if(diagnostics.length > 0){
                let errorCount = 0;
               // vscode.window.showInformationMessage(JSON.stringify(diagnostics));
    
                // Loop through each diagnostic collection and count errors       
                diagnostics.forEach(([uri, diagnosticArray]) => {
                    diagnosticArray.forEach((diagnostic) => {
                        if (diagnostic.severity === vscode.DiagnosticSeverity.Error) {
                            errorCount++;
                        }
                    });
                });  
                return errorCount;   
           }
    
    //    }




    return -1;
}

async function countLinesOfCode(dirPath: string): Promise<number> {
    let totalLines = 0;

    // Recursively read the directory and its files
    const files = await readDir(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);

        // If it's a directory, call the function recursively
        const stat = fs.statSync(filePath);
        if (stat.isDirectory()) {
            totalLines += await countLinesOfCode(filePath);
        } else if (isCodeFile(filePath)) {
            totalLines += await countLinesInFile(filePath);
        }
    }

    return totalLines;
}

async function readDir(dirPath: string): Promise<string[]> {
    return new Promise((resolve, reject) => {
        fs.readdir(dirPath, (err, files) => {
            if (err) {
                reject(err);
            } else {
                resolve(files);
            }
        });
    });
}

function isCodeFile(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return ['.js', '.ts', '.html', '.css', '.cpp', '.java', '.py', '.dart', '.c'].includes(ext);
}

async function countLinesInFile(filePath: string): Promise<number> {
    return new Promise((resolve, reject) => {
        let lines = 0;
        const stream = fs.createReadStream(filePath, 'utf8');
        
        stream.on('data', (chunk) => {
            lines += chunk.toString('utf8').split('\n').length;
        });

        stream.on('end', () => {
            resolve(lines);
        });

        stream.on('error', (err) => {
            reject(err);
        });
    });
}


// Function to return the HTML content for the Webview
function getWebviewContent(detailsMessage: string): string {
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Current Date</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 10px; background-color: black; color: white; display: flex; }
            .panel { width: 100%; position: relative; padding: 1px; display: flex; flex-direction: column; align-items: center; }
            .date {
                font-size: 24px;
                font-weight: bold;
            }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid white; padding: 4px; text-align: center; }
            td { font-size: 16px; }
            th { font-size: 18px; color: green; background-color: black; } /* Yellow text on black background */
        </style>
    </head>
    <body>
        <div class="panel">   
            <h1>Compilation History</h1><br>
            <table>
            <tr><th>${tableheader}</th></tr>
            ${tableRows}
            </table>
        </div>

    </body>
    </html>
    `;
}