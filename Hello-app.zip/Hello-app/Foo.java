public abstract class Foo {
    void method1() {}
    void method2() {};
    // consider using abstract methods or removing
    // the abstract modifier and adding protected constructors
  };