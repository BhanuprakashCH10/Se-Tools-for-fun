// Simple Java program
// FileName: "HelloWorld.java"
class HelloWorld {    
    int age;
    int color;
    int height;
    int weight;
    String name = "No Name";
    public static void tester() {
        int timepass;
        System.out.println("Hello, World");
    };
    // Your program begins with a call to main().
    // Prints "Hello, World" to the terminal window.
    public static void main(String[] args)
    {
        int datetimeprogress = 0;
        System.out.println("Hello, World");
    };
};

