import javax.crypto.spec.SecretKeySpec;

public class Keys {

    void authKeys() {
        SecretKeySpec secretKeySpec = new SecretKeySpec("my secret here".getBytes(), "AES");
        System.out.println(secretKeySpec);
    }
}