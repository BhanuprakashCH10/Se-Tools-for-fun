import * as vscode from 'vscode';
import os from 'os';

let senderId: string | undefined;
export function activate(context: vscode.ExtensionContext) {
	const username = os.userInfo().username.replace(/\s+/g, "");
	senderId = username;
  context.subscriptions.push(
	vscode.commands.registerCommand('greetingGallery.showGallery', async () => {
      const panel = vscode.window.createWebviewPanel(
        'greetingGallery',
        'Greeting Cards Gallery',
        vscode.ViewColumn.One,
        {
          enableScripts: true
        }
      );




	  const receiverIds = ['user123', 'user456', 'user789'];
	  const jsonBody = { "receiverId": username };

	  const response = await fetch('https://ykvafyh8c5.execute-api.ap-south-1.amazonaws.com/ThanksMsgProd/getThanksMsgs', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify(jsonBody)
	  });

	  const result = await response.json() as { body?: string };
	  let receivedMessages: { imageId: string; senderId: string; dateReceived: string; message: string }[] = [];

	  if (result.body) {
		const parsedBody = JSON.parse(result.body);
		if (Array.isArray(parsedBody)) {
			receivedMessages = parsedBody.map(item => ({ imageId: item.imageId, senderId: item.senderId, dateReceived:item.dateReceived, message: item.message }));
		}
	}

      console.log('Received messages from backend:', receivedMessages);
      const s3Thumbnails = [
        // Replace with your actual S3 image URLs
        {
		  id: 'ThankYou1.jpg',
          thumbnail: 'https://animateinput.s3.ap-south-1.amazonaws.com/TN_ThankYou1.jpg',
          full: 'https://animateinput.s3.ap-south-1.amazonaws.com/ThankYou1.jpg'
        },
        {
		  id: 'ThankYou2.jpg',
          thumbnail: 'https://animateinput.s3.ap-south-1.amazonaws.com/TN_ThankYou2.jpg',
          full: 'https://animateinput.s3.ap-south-1.amazonaws.com/ThankYou2.jpg'
        },
        {
			id: 'CongratsEvent1.jpg',		
			thumbnail: 'https://animateinput.s3.ap-south-1.amazonaws.com/TN_CongratsEvent1.jpg',
			full: 'https://animateinput.s3.ap-south-1.amazonaws.com/CongratsEvent1.jpg'
		  }
      ];

	  panel.webview.html = getWebviewContent_GT(
		s3Thumbnails,
		receiverIds,
		receivedMessages
	  );
    })
  );
}

export function deactivate() {}

export function getWebviewContent_GT(images: { id: string; thumbnail: string; full: string }[], receiverIds: string[], receivedMessages: { imageId: string; senderId: string; dateReceived: string; message: string }[]) {
	const thumbnailsHtml = images.map((img, index) => `
	  <label class="thumb-option">
		<input type="radio" name="thumbnail" value="${img.id}" data-full="${img.full}" ${index === 0 ? 'checked' : ''} />
		<img src="${img.thumbnail}" alt="Thumbnail ${index + 1}" />
	  </label>
	`).join('');
  
	const dropdownHtml = receiverIds.map(id => `
	  <option value="${id}">${id}</option>
	`).join('');
  
	  let rightPanelContent = '';

	  if (receivedMessages.length === 0) {
		rightPanelContent = `<p style="color: gray; padding: 10px;">No Cards Received Yet.</p>`;
	  } else {
		const listHtml = receivedMessages.map((msg, idx) => `
		<label style="display: flex; align-items: center; margin-bottom: 6px;">
		  <input 
			type="radio" 
			name="rightImage" 
			value="${msg.imageId}" 
			data-message="${msg.message || ''}"
			${idx === 0 ? 'checked' : ''} 
		  />
		  <span style="margin-left: 8px;">
			${msg.senderId} - ${msg.dateReceived}
		  </span>
		</label>
	  `).join('');
	  
	  
		const firstImageId = receivedMessages[0].imageId;
		const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
		const ext = '.jpg'; // or your actual extension
		const firstImageUrl = `${s3Base}${firstImageId}`;
	  
		rightPanelContent = `
		  <div class="right-scrollable-list">${listHtml}</div>
		  <img id="rightFullImage" src="${firstImageUrl}" alt="Selected Full Image" />
		  <div id="rightImageMessage" style="color: white; margin-top: 12px; margin-bottom: 12px; border-radius: 10px; font-style: italic;"></div>
		`;
	  }
	  
  
	const firstFullImage = images.length > 0 ? images[0].full : '';
  
	return `
	  <!DOCTYPE html>
	  <html lang="en">
	  <head>
		<style>
		  body {
			font-family: sans-serif;
			margin: 0;
			padding: 0;
			display: flex;
			height: 100vh;
			overflow: hidden;
		  }
  
		  .left-panel, .right-panel {
			padding: 16px;
			overflow-y: auto;
		  }
  
		  .left-panel {
			width: 40%;
			border-right: 1px solid #ccc;
		  }
  
		  .right-panel {
		  	position: relative;
			width: 60%;
			display: flex;
			flex-direction: column;
		  }
  
		  h2 {
			margin-top: 0;
		  }
  
		  .thumb-scroll-container {
			display: flex;
			overflow-x: auto;
			gap: 12px;
			padding-bottom: 12px;
			margin-bottom: 16px;
			border-bottom: 1px solid #ddd;
		  }
  
		  .thumb-option {
			display: flex;
			flex-direction: column;
			align-items: center;
			cursor: pointer;
		  }
  
		  .thumb-option img {
			width: 100px;
			height: 100px;
			object-fit: cover;
			border: 2px solid transparent;
			border-radius: 6px;
		  }
  
		  .thumb-option input:checked + img {
			border-color: #007acc;
		  }
  
		  #fullImage {
			width: 90%;
			height: 300px;
			object-fit: contain;
			border-radius: 8px;
			background-color: #f0f0f0;
			margin-bottom: 12px;
			display: block;
		  }
  
		  .form-section {
			display: flex;
			flex-direction: column;
			align-items: flex-start;
			gap: 12px;
		  }
  
		  #message {
			width: 90%;
			padding: 8px;
			font-size: 14px;
			border: 1px solid #ccc;
			border-radius: 4px;
			transition: border-color 0.3s;
		  }
  
		  #message:focus {
			border-color: #007acc;
			outline: none;
		  }
  
		  .bottom-row {
			display: flex;
			gap: 10px;
			width: 90%;
		  }
  
		  select {
			flex: 1;
			padding: 8px;
			font-size: 14px;
			border: 1px solid #ccc;
			border-radius: 4px;
			transition: border-color 0.3s;
		  }
  
		  select:focus {
			border-color: #007acc;
			outline: none;
		  }
  
		  button {
			min-width: 80px;
			padding: 8px 12px;
			font-size: 14px;
			border: none;
			border-radius: 4px;
			background-color: #ccc;
			color: #fff;
			cursor: not-allowed;
			transition: background-color 0.3s;
		  }
  
		  button:enabled {
			background-color: #007acc;
			cursor: pointer;
		  }
  
		  .right-scrollable-list {
			max-height: 100px;
			overflow-y: auto;
			border: 1px solid  #444;
			padding: 8px;
			border-radius: 6px;
			margin-bottom: 16px;
			background-color: #222;
		  }

		  #fullImage,
		  #rightFullImage {
			max-width: 100%;
			height: 300px;
			object-fit: contain;
			background-color: #222;
			border-radius: 6px;
		  }
		.points-display {
		position: absolute;
		top: 10px;
		right: 10px;
		font-size: 16px;
		font-weight: bold;
		/* Additional styling as needed */
		}
		</style>
	  </head>
	  <body>
		<div class="left-panel">
		  <h2>Select a Greeting Card</h2>
  
		  <div class="thumb-scroll-container">
			${thumbnailsHtml}
		  </div>
  
		  <img id="fullImage" src="${firstFullImage}" alt="Full Image Preview" />
  
		  <div class="form-section">
			<textarea id="message" rows="3" placeholder="Enter your message..."></textarea>
			<div class="bottom-row">
			  <select id="receiver">
				<option value="">-- Select Receiver --</option>
				${dropdownHtml}
			  </select>
			  <button id="sendButton" disabled>Send</button>
			</div>
		  </div>
		</div>
  

  
		<div class="right-panel">
		<div class="points-display" id="pointsDisplay"></div>
		<h2>Cards Received</h2>
		${rightPanelContent}
		</div>

		<script>
		  const fullImage = document.getElementById('fullImage');
		  const sendButton = document.getElementById('sendButton');
		  const receiverInput = document.getElementById('receiver');
		  const messageInput = document.getElementById('message');
		  const rightFullImage = document.getElementById('rightFullImage');
		  const rightImageMessage = document.getElementById('rightImageMessage');
		  let selectedImageId = document.querySelector('input[name="thumbnail"]:checked')?.value;

			const apiUrl = 'https://your-backend-api.com/endpoint'; // Replace with your API endpoint

			fetch(apiUrl, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({ "userid": username }),
			})
			.then(response => {
				if (!response.ok) {
				throw new Error('Network response was not ok');
				}
				return response.json();
			})
			.then(data => {
				const points = (data as { points: number }).points; // Adjust according to your API response structure
				displayPoints(points);
			})
			.catch(error => {
				console.error('There was a problem with the fetch operation:', error);
			});

			function displayPoints(points) {
			const pointsDisplay = document.getElementById('pointsDisplay');
			pointsDisplay.textContent = \`Points: \${points}\`;
			}

  
			// Set initial right panel full image on load
			(function initRightPanelImageAndMessage() {
			const firstRightRadio = document.querySelector('input[name="rightImage"]:checked');
			if (firstRightRadio) {
				const id = firstRightRadio.value;
				const msg = firstRightRadio.dataset.message;
				const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
				const ext = '.jpg';

				rightFullImage.src = s3Base + id;
				const formattedMessage = msg.replace(/\\n/g, \'<br>\');
				rightImageMessage.innerHTML = formattedMessage;
			}
			})();


		  document.querySelectorAll('input[name="thumbnail"]').forEach(radio => {
			radio.addEventListener('change', (e) => {
			  selectedImageId = e.target.value;
			  const fullUrl = e.target.getAttribute('data-full');
			  fullImage.src = fullUrl;
			  fullImage.style.display = 'block';
			  validateInputs();
			});
		  });
  
			document.querySelectorAll('input[name="rightImage"]').forEach(radio => {
				radio.addEventListener('change', (e) => {
					const id = e.target.value;
					const msg = e.target.dataset.message;
					const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
					const ext = '.jpg'; //only jpg supported for now

					rightFullImage.src = s3Base + id;
					const formattedMessage = msg.replace(/\\n/g, \'<br>\');
					rightImageMessage.innerHTML = formattedMessage;
				});
			});
  
		  receiverInput.addEventListener('change', validateInputs);
		  messageInput.addEventListener('input', validateInputs);
  
		  function validateInputs() {
			const message = messageInput.value.trim();
			const receiver = receiverInput.value;
			const enable = selectedImageId && message && receiver;
			sendButton.disabled = !enable;
		  }
  
		  sendButton.addEventListener('click', async () => {
			const message = messageInput.value.trim();
			const receiverId = receiverInput.value;
  
			if (!selectedImageId || !receiverId || !message) return;
  
			const payload = {
			  senderId: '${senderId}',
			  imageId: selectedImageId,
			  receiverId: receiverId,
			  message: message
			};
  
			sendButton.disabled = true;
  
			try {
			  const response = await fetch('https://2zisqo65p2.execute-api.ap-south-1.amazonaws.com/SayThanksProd/updateThanks', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(payload)
			  });
  
			  if (response.ok) {
				alert('Greeting card sent successfully!');
				messageInput.value = '';
				receiverInput.value = '';
				validateInputs();
			  } else {
				alert('Failed to send greeting card.');
				sendButton.disabled = false;
			  }
			} catch (err) {
			  console.error(err);
			  alert('Error sending greeting card.');
			  sendButton.disabled = false;
			}
		  });
  
		  // Initial validation
		  validateInputs();
		</script>
	  </body>
	  </html>
	`;
  }
  

