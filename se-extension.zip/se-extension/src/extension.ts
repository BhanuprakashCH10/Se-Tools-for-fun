import vscode from 'vscode';
import os from 'os';

import { exec } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';

let senderId: string | undefined;
let receiverIds: string[] = [];
let totalGreetings: number = 0;


let panel: vscode.WebviewPanel | undefined;
let totalCodeSmell: string | undefined = "";
let checkboxHtml: string | undefined = "";
let tableheader = `<tr><th>FileName</th><th>Line #</th><th>Observations</th></tr>`;
let tableRows: string | undefined = "";
let rulesets: string | undefined = "";
let savedSelections: string[] | undefined = undefined;
let processingStatus: string | undefined = "";

let currentPanel: vscode.WebviewPanel | undefined;
let videoCount = 0;
let totalSongs: number;
let songIndex: number;
let userIds: string[] = [];

let tableheader_CE = `<tr><th>Date</th><th>LOC</th><th>Errors</th><th>Avg (Err/LOC)</th><th>Momentum</th></tr>`;
let tableRows_CE: string | undefined = "";
let analysedData_CE: string | undefined = "";
let panel_CE: vscode.WebviewPanel | undefined;
let panel_GT: vscode.WebviewPanel | undefined;

function activate(context: vscode.ExtensionContext) {
    const username = os.userInfo().username.replace(/\s+/g, "");
    senderId = username;

    let javaCodeSmellAnalyzer = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    javaCodeSmellAnalyzer.text = `$(play) Codesmell`;
    javaCodeSmellAnalyzer.tooltip = "Analyze Java Code Smell";
    javaCodeSmellAnalyzer.command = "extension.analyzeJavaCodeSmell";
    javaCodeSmellAnalyzer.show();
  

    let takeAbreakExtension = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    takeAbreakExtension.text = `$(play) BreakTime`;
    takeAbreakExtension.tooltip = "Take a Break...Relax";
    takeAbreakExtension.command = "seExtension.takeABreak";
    takeAbreakExtension.show();

    let compileCode = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    compileCode.text = `$(play) Compile`;
    compileCode.tooltip = "Show coding efficiency through Compilation errors";
    compileCode.command = "extension.countCompilationDetails";
    compileCode.show();

    let sayThanks = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    sayThanks.text = `$(play) SayThanks`;
    sayThanks.tooltip = "Show coding efficiency through Compilation errors";
    sayThanks.command = "extension.Appreciate";
    sayThanks.show();



    // detect the termination of degub/compilation 
    vscode.debug.onDidTerminateDebugSession( async (session) => {

        let totalErrors = await storeCompilationDetails(context);
        if (totalErrors > 0) {

            displayCompilationHistory(context);
        }


    });

    // Register the command to count lines of code and compilation errors
    let disposable = vscode.commands.registerCommand('extension.countCompilationDetails', async  () => {

        if (panel_CE) {
            panel_CE.reveal(vscode.ViewColumn.One);       
        }
        else{
            panel_CE = vscode.window.createWebviewPanel('Compilation-Errors', 'Compilation-Errors', vscode.ViewColumn.One, { enableScripts: true });
        }

            let totalErrors = await storeCompilationDetails(context);
            if (totalErrors > 0) {
                displayCompilationHistory(context);
            }

    });

    context.subscriptions.push(compileCode, disposable);

    let sayThanksDisposable = 	vscode.commands.registerCommand('extension.Appreciate', async () => {

                // If panel already exists, reveal it and return
                if (panel_GT) {
                    panel_GT.reveal(vscode.ViewColumn.One);       
                }
                else{
                    panel_GT = vscode.window.createWebviewPanel(
                        'Say Thanks',
                        'Appreciate your friends',
                            vscode.ViewColumn.One,
                            {
                                enableScripts: true
                            }
                        );
                }  
  
        getGreetingCount();  
        await fetchAllReceivers();  
  
        const jsonBody = { "receiverId": username };
  
        const response = await fetch('https://ykvafyh8c5.execute-api.ap-south-1.amazonaws.com/ThanksMsgProd/getThanksMsgs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(jsonBody)
        });
  
        const result = await response.json() as { body?: string };
        let receivedMessages: { imageId: string; senderId: string; dateReceived: string; message: string }[] = [];
  
        if (result.body) {
          const parsedBody = JSON.parse(result.body);
          if (Array.isArray(parsedBody)) {
              receivedMessages = parsedBody.map(item => ({ imageId: item.imageId, senderId: item.senderId, dateReceived:item.dateReceived, message: item.message }));
          }
      }
  
       let s3Thumbnails: { id: string; thumbnail: string; full: string }[] = [];
       for (let i = 1; i <= totalGreetings; i++) {
          const imageId = `GreetingCard${i}.jpg`;
          const thumbnailId = `TN_${imageId}`;
          const thumbnailUrl = `https://animateinput.s3.ap-south-1.amazonaws.com/${thumbnailId}`;
          const fullUrl = `https://animateinput.s3.ap-south-1.amazonaws.com/${imageId}`;
          s3Thumbnails.push({
            id: imageId,
            thumbnail: thumbnailUrl,
            full: fullUrl
          });
        }
  
        if (panel_GT) {
            panel_GT.webview.html = getWebviewContent_GT(
          s3Thumbnails,
          receiverIds,
          receivedMessages
        );
    }
            // Handle webview disposal (when closed)
            panel_GT?.onDidDispose(() => {
                panel_GT = undefined; // Reset the reference
            }, null, context.subscriptions);
      });

      context.subscriptions.push(sayThanks, sayThanksDisposable);

	// Register the command to clear the workspaceState for compilationData
	let clearDisposable = vscode.commands.registerCommand('extension.clearSpecificWorkspaceState', () => {
        // Clear a specific workspaceState key
        context.workspaceState.update('compilationData', []); 
      //  storedData = [];
      //  storedData.length = 0;

        vscode.window.showInformationMessage(`Workspace state for 'compilationData' has been cleared.`);
    });

	context.subscriptions.push(clearDisposable);

    // Register the command to retrieve and display the last 20 compilation details
    let retrieveDisposable = vscode.commands.registerCommand('extension.retrieveLastCompilationDetails', () => {

        displayCompilationHistory(context);

    });

    context.subscriptions.push(retrieveDisposable);

    // Event listener for when a debugging session ends
    const buildTaskListener = vscode.tasks.onDidEndTask(async (event) => {
        if (event.execution.task.name === 'build') { // Check if it's a build task (you can customize task name)
            const finishTime = new Date().toLocaleString(); // Get the current date and time
            vscode.window.showInformationMessage(`Build completion time : ${finishTime}`);
        }
    });

    context.subscriptions.push(buildTaskListener);


    let checkboxinput = vscode.commands.registerCommand('extension.analyzeJavaCodeSmell', () => {
        // If panel already exists, reveal it and return
        if (panel) {
            panel.reveal(vscode.ViewColumn.One);       
        }
        else{
            panel = vscode.window.createWebviewPanel(
                'Code-Smell', 'Code-Smell', vscode.ViewColumn.One, { enableScripts: true });
        }  
        rulesets = getPMDOptions(context);
        generateTableHtml_JCS(context, "");
    
        // Handle messages from the WebView
        panel.webview.onDidReceiveMessage(
            message => {
                if (message.command === 'run') {
                    tableRows = "";
                    const workspaceState = context.workspaceState;
                    workspaceState.update('selectedOptions', message.selected);
                    const selectedWithValues = message.selected.map((key: string) => `${key},`);
                    rulesets = getPMDOptions(context);
                    totalCodeSmell = "";
                    showCodeSmell(context);
                }
            },
            undefined,
            context.subscriptions
        );
            // Handle webview disposal (when closed)
            panel.onDidDispose(() => {
                panel = undefined; // Reset the reference
            }, null, context.subscriptions);
        });
    
        context.subscriptions.push(javaCodeSmellAnalyzer, checkboxinput);

 
	let getVideoListDisposable = vscode.commands.registerCommand('seExtension.takeABreak', async () => {
        await getVideoCount();
        // Fetch all users
        await fetchAllUsers();
      // Retrieve usersList from global state (default empty array if not found)
      const usersList: string[] = context.globalState.get("usersList", []);
      if (!usersList.includes(username)) {
        const success = await registerUser(username);
        if (success) {
          usersList.push(username);
          await context.globalState.update("usersList", usersList);
        }
      }

       fetchAndDisplayVideos(context, username);

    });

    context.subscriptions.push(takeAbreakExtension, getVideoListDisposable);
}

async function getVideoCount()
{
    const url = "https://animateinput.s3.ap-south-1.amazonaws.com/videocount.txt";

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const text = await response.text();
        const numberMatch = text.match(/\d+/); // Extract first number from file

        if (numberMatch) {
            totalSongs = parseInt(numberMatch[0], 10);
        } else {
            totalSongs = 0;
        }
    } catch (error: any) {
        vscode.window.showErrorMessage(`Error fetching file: ${error.message}`);
        totalSongs = 0;
    }
}

async function fetchAllUsers() {

    const getAllUsersApiURL = "https://w0jnm95oyc.execute-api.ap-south-1.amazonaws.com/animal/userlist";
    const jsonBody = {};

    try {
        const response = await fetch(getAllUsersApiURL, {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=UTF-8" },
            body: JSON.stringify(jsonBody)
        });
        
        const result = await response.json() as { body?: string };

        
        
        if (result.body) {
            const parsedBody = JSON.parse(result.body);
            if (Array.isArray(parsedBody)) {
                userIds = parsedBody.map(item => item.userid).filter(id => id);
            }
        }

    } catch (error) {
        const errorMessage = (error as any).message || "Unknown error";
        vscode.window.showErrorMessage("API request failed: " + errorMessage);
    }
}

async function fetchAndDisplayVideos(context: vscode.ExtensionContext, username?: string) {


  //  const getMsgsApiURL = "https://pvu9i3cor7.execute-api.ap-south-1.amazonaws.com/prod/getvideos";
    const getMsgsApiURL = "https://qb1n4uw5b6.execute-api.ap-south-1.amazonaws.com/animal/getvideowithmsg";
    const jsonBody = { "userid": username };

    // If currentPanel already exists, reveal it and return
    if (currentPanel) {
        currentPanel.reveal(vscode.ViewColumn.One);       
    }
    else{
        currentPanel = vscode.window.createWebviewPanel('Break-Time', 'Break-Time', vscode.ViewColumn.One, { enableScripts: true });
    }
    
    try {
        const response = await fetch(getMsgsApiURL, {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=UTF-8" },
            body: JSON.stringify(jsonBody)
        });
        
        const result = await response.json() as { body?: string };
    let messageIds: { id: string; msg: string; lang: string }[] = [];

        
/*        
        if (result.body) {
            const parsedBody = JSON.parse(result.body);
            if (Array.isArray(parsedBody)) {
                messageIds = parsedBody.map(item => item.messageid).filter(id => id);
                messageTexts = parsedBody.map(item => item.messagetext).filter(id => id);
            }
        }
*/

        if (result.body) {
            const parsedBody = JSON.parse(result.body);
            if (Array.isArray(parsedBody)) {
                messageIds = parsedBody.map(item => ({ id: item.messageid, msg: item.messagetext, lang:item.language }));
            }
        }

        if (messageIds.length <= videoCount) {
            vscode.window.showInformationMessage("No New Videos avilable.");
        }
        else{
            videoCount = messageIds.length;
        }
        const watchedVideos = new Set<string>(context.globalState.get<string[]>("watchedVideos", []));
   

        if (currentPanel) {
            currentPanel.webview.html = getWebviewContent(messageIds.map(item => ({ id: item.id, msg: item.msg, lang:item.lang })), watchedVideos, username || "Guest", totalSongs);
        }
        
        currentPanel.webview.onDidReceiveMessage(            
            (message) => {
                if (message.command === 'playVideo') {
                    watchedVideos.add(message.selectedId);
                    context.globalState.update("watchedVideos", Array.from(watchedVideos));
                } 
                else if (message.command === 'refreshVideos') {
                    fetchAndDisplayVideos(context, username); // Refresh video list
                }
                else if (message.command === 'noSelection') {
                    vscode.window.showInformationMessage("Please select a Video to Play");
                }
                else if (message.command === 'emptySendToUser') {
                    vscode.window.showInformationMessage("Please select a user to send message.");
                }
                else if (message.command === 'emptyMessage') {
                    vscode.window.showInformationMessage("Please enter a message to Send.");
                }
                else if (message.command === 'reset') {
                    if (currentPanel) {
                        currentPanel.reveal(vscode.ViewColumn.One);       
                    }
                    else{
                        currentPanel = vscode.window.createWebviewPanel('Break-Time', 'Break-Time', vscode.ViewColumn.One, { enableScripts: true });
                    }
                    if (currentPanel) {
                        currentPanel.webview.html = getWebviewContent(messageIds.map(item => ({ id: item.id, msg: item.msg, lang:item.lang })), watchedVideos, username || "Guest", totalSongs);
                    }
                }

            },
            undefined,
            context.subscriptions
        );
        // Handle webview disposal (when closed)
        currentPanel.onDidDispose(() => {
            currentPanel = undefined; // Reset the reference
        }, null, context.subscriptions);
    } catch (error) {
        const errorMessage = (error as any).message || "Unknown error";
        vscode.window.showErrorMessage("API request failed: " + errorMessage);
    }
}


function getWebviewContent(messageIds: { id: string; msg: string; lang:string }[],watchedVideos: Set<string>, username: string, songsCount: number): string {

    const values = [5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, -40000];
    const shuffledValues = values.sort(() => Math.random() - 0.5);
    let gameResult: string | undefined;

    const videoURL = "https://animateoutput.s3.ap-south-1.amazonaws.com/";
    const sendMsgApiURL = "https://9xbaecf7o2.execute-api.ap-south-1.amazonaws.com/prod/callanimal";

    const options = userIds
    .map((user) => `<li onclick="selectUser('${user}')">${user}</li>`)
    .join("");

    let sortedMessageIds = Array.from(messageIds).sort((a, b) => b.id.localeCompare(a.id));
    const radioButtons = sortedMessageIds.map(({id, msg, lang}) => {
        const isWatched = watchedVideos.has(id);
        return `
            <input type="radio" name="messageid" value="${msg} [${lang}]" id="${id}" msg="${msg}">
            <label for="${id}" style="color: ${isWatched ? 'grey' : 'white'}; font-weight: ${isWatched ? 'normal' : 'bold'};">${id}</label><br>
        `;
    }).join("");

    return `<!DOCTYPE html>
    <html>
    <head>
        <title>Submit Message</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 10px; background-color: black; color: white; display: flex; }
            .header { position: absolute; top: 10px; right: 20px; font-size: 14px; color: lightgray; }
            .left-currentPanel, .right-currentPanel { padding: 4px; }
            .scrollable-list {flex-grow: 1; overflow-y: auto;}

            .left-currentPanel { width: 20%; float: left; height: 75vh; border-right: 2px solid grey; display: flex; flex-direction: column; }
            .center-currentPanel { width: 47%; position: relative; padding: 5px; border-right: 2px solid grey; display: flex; flex-direction: column; align-items: center; }
            .right-currentPanel { width: 33%; position: relative; padding: 5px; display: flex; flex-direction: column; align-items: center; }
            select { width: 100px; margin-left: 10px; }
            .button-container { display: flex; gap: 10px; justify-content: left; background: black; padding: 8px; }
            
            .left-currentPanel button { width: 80px; padding: 6px; background-color: #007acc; color: white; border: none; cursor: pointer; } 
            .center-currentPanel button { width: 80px; padding: 6px; background-color: #007acc; color: white; border: none; cursor: pointer; }         

            #videoContainer {
                position: relative;
                width: 420px;
                height: 320px;
                border: 3px solid #007acc;
                border-radius: 8px;
                resize: both;
                overflow: hidden;
                background-color: black;
            }
            video {
                width: 100%;
                height: 100%;
                object-fit: contain;
            }
            #dragHandle {
                width: 100%;
                height: 20px;
                background: #007acc;
                cursor: move;
                text-align: center;
                color: white;
                font-weight: bold;
            }
            textarea {
                width: 95%;
                max-width: 420px;
                height: 60px;
                margin-top: 10px;
                border: 1px solid #007acc;
                border-radius: 8px;
                padding: 3px;
                background-color: #222;
                color: white;
                resize: none;
            }
            button:hover { background-color: #005f99; }

            .dropdown-container { position: relative; display: inline-block; border: 1px solid #007acc; }
            .dropdown-input { width: 180px; padding: 6px; border: 1px solid #007acc; border-radius: 5px; }
            .dropdown-list {
                position: absolute;
                width: 200px;
                max-height: 150px;
                overflow-y: auto;
                border: 1px solid #007acc;
                border-top: none;
                background: grey;
                display: none;
                z-index: 1000;
                list-style: none;
                padding: 0;
                margin: 0;
            }
            .dropdown-list li {
                padding: 2px;
                cursor: pointer;
                color: black;  /* Ensure text is black */
                background: grey; /* Ensure background is white */
            }
            .dropdown-list li:hover {
                background: #f0f0f0;
            }


            .right-currentPanel {
                display: flex;
                flex-direction: column;
                align-items: center;
                flex-grow: 1;
                padding: 10px;
            }
            .right-currentPanel  .header {
                width: 100%;
                text-align: center;
                font-size: 18px;
                font-weight: bold;
                margin-bottom: 5px;
                padding: 5px;
                background: none;
                color: black;
            }
           .right-currentPanel .grid-container {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                grid-template-rows: repeat(3, 1fr);
                gap: 10px;
                padding: 10px;
                border: 2px solid grey;
                background-color: #f5f5f5;
            }
            .right-currentPanel .button {
                width: 90px;
                height: 60px;
                background: linear-gradient(to top, #e0e0e0, #ffffff);
                color: #333;
                border: 3px solid #888;
                border-radius: 8px;
                box-shadow: inset 0px -5px 5px rgba(0, 0, 0, 0.2), inset 0px 5px 5px rgba(255, 255, 255, 0.7), 3px 3px 5px rgba(0, 0, 0, 0.3);
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
                text-align: center;
                position: relative;
            }
            .right-currentPanel .button:hover {
                background: linear-gradient(to top, #d0d0d0, #ffffff);
            }
            .right-currentPanel .green {
                background: green !important;
                font-weight: bold;
                color: white;
            }
            .right-currentPanel .orange {
                background: orange !important;
                font-weight: bold;
                color: black;
            }
            .right-currentPanel .red {
                background: red !important;
                font-weight: bold;
                color: white;
            }
            .right-currentPanel .disabled {
                pointer-events: none;
                opacity: 0.5;
            }
            .right-currentPanel  .score-table {
                margin-top: 10px;
                border-collapse: collapse;
                width: 200px;
                text-align: center;
                border: 1px solid white;
            }
            .right-currentPanel .score-table th {
                background: white;
                color: blue;
                font-weight: bold;
            }
            .right-currentPanel .score-table th, .score-table td {
                border: 1px solid white;
                padding: 5px;
                font-size: 16px;
            }
            #add-rounded-sum {
                margin-top: 10px;
                display: none;
                background: linear-gradient(to top, #ffff00, #ffcc00);
                color: black;
                font-weight: bold;
                padding: 2px;
                border: 3px solid #ffaa00;
                border-radius: 8px;
                cursor: pointer;
                box-shadow: inset 0px -5px 5px rgba(255, 255, 0, 0.5), inset 0px 5px 5px rgba(255, 204, 0, 0.7), 3px 3px 5px rgba(255, 153, 0, 0.5);
            }
            #add-rounded-sum:hover {
                background: linear-gradient(to top, #ffcc00, #ffff00);
            }
            .right-currentPanel .medal {
                display: none;
                width: 280px;
                height: 40px;
                background: gold;
                border-radius: 10%;
                text-align: center;
                font-size: 18px;
                font-weight: bold;
                line-height: 30px;
                color: black;
                margin-top: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            }
            .right-currentPanel .reset-button {
                display: none;
                margin-top: 10px;
                padding: 6px;
                font-size: 16px;
                font-weight: bold;
                background: red;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .right-currentPanel .reset-button:hover {
                background: darkred;
            }
            .right-currentPanel .ins-button {
                display: block;
                margin-top: 10px;
                padding: 6px;
                font-size: 16px;
                font-weight: bold;
                background: blue;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .right-currentPanel .ins-button:hover {
                background: darkred;
            }
          .right-currentPanel .suitcase {
                width: 80px;
                height: 60px;
                background: linear-gradient(to top, #e0e0e0, #ffffff);
                color: white;
                border: 3px solid #888;
                border-radius: 8px;
                box-shadow: inset 0px -5px 5px rgba(0, 0, 0, 0.2), inset 0px 5px 5px rgba(255, 255, 255, 0.7), 3px 3px 5px rgba(0, 0, 0, 0.3);
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
                text-align: center;
                position: relative;
            }
            .right-currentPanel .button::before {
                content: "";
                position: absolute;
                top: -10px;
                width: 30px;
                height: 10px;
                background-color: grey;
                border-radius: 5px 5px 0 0;
            }
            .right-currentPanel .button .handle {
                width: 50px;
                height: 10px;
                background-color: white;
                position: absolute;
                top: -10px;
                border-radius: 5px;
            }
            .right-currentPanel .suitcase:hover {
                background: linear-gradient(to top, #d0d0d0, #ffffff);
            }
            .right-currentPanel .instructions-container {
            max-height: 90px; /* roughly 4 lines depending on font-size */
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 6px;
            display: none; /* initially hidden */
            margin-top: 6px;
            line-height: 1.5;
            }

        </style>
    </head>
    <body>
        <div class="header"><strong>${username}</strong></div>
        <div class="left-currentPanel">
            <h2>Select a Video</h2>
            <div class="scrollable-list">
                ${radioButtons}
            </div>
            <div class="button-container">
                <button onclick="playSelectedVideo()">Play</button>
                <button id="Refresh" onclick="refreshVideos()" style="background-color: #007acc;">Refresh</button>
            </div>
            <div class="button-container">
                <button onclick="playRandomSong()">Song</button>
                <button onclick="stopRandomSong()">Stop</button>
            </div>
        </div>


        <div class="center-currentPanel">
            <h3></h3>
            <div id="videoContainer">
                <div id="dragHandle">Drag</div>
                <video id="videoPlayer" controls autoplay>
                    <source id="videoSource" src="" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>


            <!-- Comment input and language selection -->

                <textarea id="messageBox" maxlength="150" placeholder="Enter your message (max 150 chars)"></textarea>
                <div class="button-container">
                    <select id="languageSelect" onchange="updateLanguage()">
                        <option value="en">English</option>
                        <option value="gu">Gujarati</option>
                        <option value="hi">Hindi</option>
                        <option value="kn">Kannada</option>
                        <option value="ml">Malayalam</option>
                        <option value="mr">Marathi</option>
                        <option value="ta">Tamil</option>
                        <option value="te">Telugu</option>
                        <option value="or">Odia</option>
                    </select>
                    <div class="dropdown-container">
                        <input type="text" id="userSearch" class="dropdown-input" placeholder="Send to..." oninput="filterUsers()" onclick="toggleDropdown()">
                        <ul id="userDropdown" class="dropdown-list">${options}</ul>
                    </div>
                    <button onclick="submitMessage()">Send</button>
                </div>

                   
        </div>

        <div class="right-currentPanel">
            <h3></h3>
            <div class="grid-container" id="grid">
                ${shuffledValues.map((value, index) => `<button class="button" id="btn${index + 1}" data-value="${value}" onclick="userClick(${index + 1})">${index + 1}</button>`).join('')}
            </div>
            <div id="medal" class="medal"></div>
            <table class="score-table">
                <tr><th>User</th><th>Comp</th></tr>
                <tr><td id="user-score1">0</td><td id="comp-score1">0</td></tr>
                <tr><td id="user-score2">0</td><td id="comp-score2">0</td></tr>
                <tr><td id="user-score3">0</td><td id="comp-score3">0</td></tr>
                <tr><td id="user-score4">0</td><td id="comp-score4">0</td></tr>
                <tr><td id="user-total">0</td><td id="comp-total">0</td></tr>
            </table>
            <br>
            <button id="add-rounded-sum" style="margin-top: 10px; display: none; color: #333;" onclick="addofferValueToUserTotal();">Add Rounded Sum</button>
            <button id="reset" class="reset-button" onclick="resetGame()">Play Again</button>  
            <button id="instruction" class="ins-button" onclick="toggleInstructions()">Instructions</button>  

            <div id="instructions" class="instructions-container">
                <ol>
                <li>You will play with the Computer</li>                
                <li>Each box will contain random amount between ₹5K to ₹40K in increments of ₹5K</li>
                <li>One box will have a negative amount ₹-40K</li>
                <li>Click Any of the 9 boxes to start</li>
                <li>The amount You see in the clicked box will be added to your account</li>
                <li>Computer will select a box after You</li>
                <li>The amount in the computer clicked box will be added to Computer's account</li>
                <li>Computer will randomly give you an Offer to quit the game</li>
                <li>You can choose to avail computer's  Offer to Quit. If so the amount will be added to your account</li>
                <li>Once you chose computer's  Offer to Quit, You will not be allowed to select any boxes. But the computer will select its remaining boxes</li>
                <li>Either You or Computer having highest amount in account is the Winner at the end</li>
                <li>The Offer to Quit amount from computer is calculative and not random. So your chances of winning is high</li>
                </ol>
            </div>

        </div>

        <script>

            let selectedUser = "";
            songIndex = 0;
            totalSongs = ${songsCount};
            console.log('totalSongs ', totalSongs);

            function toggleDropdown() {
                document.getElementById("userDropdown").style.display = "block";
            }

            function selectUser(user) {
                document.getElementById("userSearch").value = user;
                document.getElementById("userDropdown").style.display = "none";
                selectedUser = user;
            }

            function filterUsers() {
                let input = document.getElementById("userSearch").value.toLowerCase();
                let items = document.querySelectorAll("#userDropdown li");
                items.forEach(item => {
                    item.style.display = item.textContent.toLowerCase().includes(input) ? "block" : "none";
                });
            }

            document.addEventListener("click", function(event) {
                if (!event.target.closest(".dropdown-container")) {
                    document.getElementById("userDropdown").style.display = "none";
                }
            });

            // Function to update message ID colors based on state
            function updateMessageColors(selectedId) {
                document.querySelectorAll('input[name="messageid"]').forEach(radio => {
                    const safeId = CSS.escape(radio.id); // Escape special characters
                    const label = document.getElementById(safeId); // Get the label directly by ID

                    if (label) {
                        if (radio.id === selectedId) {
                            label.style.color = "grey"; // Change selected ID to the specified color
                        } else {
                            label.style.color = radio.dataset.watched === "true" ? "grey" : "white"; 
                            label.style.fontWeight = radio.dataset.watched === "true" ? "normal" : "bold";
                        }
                    }
                });
            }

            function updateLanguage() {
                const selectedLanguage = document.getElementById("languageSelect").value;
                // Change input method for the message box
                setIME(selectedLanguage);
            }

            function playRandomSong() {
                    console.log('Inside playRandomSong');
                    console.log('song count is ', totalSongs);
                    songIndex = songIndex < totalSongs ? songIndex + 1 : 1;
                    let randUrl = "https://animateinput.s3.ap-south-1.amazonaws.com/randsong" + songIndex + ".mp4";
                    console.log('url ', randUrl);
                    const videoPlayer = document.getElementById('videoPlayer');
                    const videoSource = document.getElementById('videoSource');

                    videoSource.src = randUrl;
                    videoPlayer.load();
                    videoPlayer.playbackRate = 0.75; // Set playback speed to 0.75x
                    enablePiP(); // Auto-enable PiP
            }
            function stopRandomSong() {
               
                    const videoPlayer = document.getElementById('videoPlayer');
                    if (videoPlayer) {
                        videoPlayer.pause();  // Pause the video
                        videoPlayer.currentTime = 0;  // Reset to the beginning
                    }
            }

            function playSelectedVideo() {
                const selected = document.querySelector('input[name="messageid"]:checked');
                const selectedMsg = selected.msg;
                
                if (selected) {
                    const videoUrl = '${videoURL}' + selected.id;
                    const videoPlayer = document.getElementById('videoPlayer');
                    const videoSource = document.getElementById('videoSource');

                    videoSource.src = videoUrl;
                    videoPlayer.load();
                    videoPlayer.playbackRate = 0.75; // Set playback speed to 0.75x
                    enablePiP(); // Auto-enable PiP
                    updateMessageColors(selected.value);
                    const messageBox = document.getElementById("messageBox");
                    messageBox.placeholder = selected.value;
                    vscode.postMessage({ command: 'playVideo', selectedId: selected.id, selectedMessage: selected.value });
                } else {
                    vscode.postMessage({ command: 'noSelection' });
                }
            }
            function refreshVideos() {
                const refreshButton = document.getElementById('Refresh');
                refreshButton.disabled = true; // Disable button to prevent multiple clicks
                refreshButton.style.backgroundColor = '#808080'; // Change color to grey
                vscode.postMessage({ command: 'refreshVideos' });
                setTimeout(() => {
                    refreshButton.disabled = false; // Re-enable after API call (assuming response comes quickly)
                    refreshButton.style.backgroundColor = '#007acc'; // Change back to blue
                }, 5000); // Adjust timeout if needed based on actual response time
            }

            async function enablePiP() {
                const video = document.getElementById('videoPlayer');
                if (document.pictureInPictureEnabled && !video.disablePictureInPicture) {
                    try {
                        await video.requestPictureInPicture();
                    } catch (error) {
                        console.error("PiP failed:", error);
                    }
                }
            }

            function submitMessage() {
                console.log("Submitting message...");
                const selected = document.querySelector('input[name="messageid"]:checked');
                if (!selectedUser) {
                    vscode.postMessage({ command: 'emptySendToUser'});
                    alert("Please select a user to send message.");
                    return;
                }
                const message = document.getElementById('messageBox').value.trim();
                if (message.length === 0) {
                    vscode.postMessage({ command: 'emptyMessage'});
                    alert("Message cannot be empty.");
                    return;
                }
                const selectedLanguage = document.getElementById('languageSelect').value; // Get selected language

                fetch('${sendMsgApiURL}', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },

                    body: JSON.stringify(
                                            { 
                                                "userid": '${username}',
                                                "message": message,
                                                "receiverid": selectedUser,
                                                "language": selectedLanguage,
                                                "animal": "cm"
                                            }
                                        )
                })
                .then(response => response.json())
                .then(data => {
                    console.log("Message submitted successfully!");
                    document.getElementById('messageBox').value = ""; // Clear input
                })
                .catch(error => {
                    console.error("Error submitting message:", error);
                    alert("Failed to submit message.");
                });
            }
            const vscode = acquireVsCodeApi();

            // Dragging functionality
            const videoContainer = document.getElementById("videoContainer");
            const dragHandle = document.getElementById("dragHandle");
            let isDragging = false, offsetX = 0, offsetY = 0;

            dragHandle.addEventListener("mousedown", (e) => {
                isDragging = true;
                offsetX = e.clientX - videoContainer.offsetLeft;
                offsetY = e.clientY - videoContainer.offsetTop;
            });

            document.addEventListener("mousemove", (e) => {
                if (isDragging) {
                    videoContainer.style.left = (e.clientX - offsetX) + "px";
                    videoContainer.style.top = (e.clientY - offsetY) + "px";
                }
            });

            document.addEventListener("mouseup", () => {
                isDragging = false;
            });


            function setIME(language) {
                const messageBox = document.getElementById("messageBox");

                if (language === "ta") {
                    messageBox.setAttribute("lang", "ta");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "உங்கள் செய்தியை உள்ளிடவும்"; // Tamil placeholder
                }
                else if (language === "te") {
                    messageBox.setAttribute("lang", "te");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "మీ సందేశాన్ని నమోదు చేయండి"; // Telugu placeholder
                } 
                else if (language === "ml") {
                    messageBox.setAttribute("lang", "'ml");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "നിങ്ങളുടെ സന്ദേശം നൽകുക"; //Malayalam
                }
                else if (language === "kn"){
                    messageBox.setAttribute("lang", "kn");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "ನಿಮ್ಮ ಸಂದೇಶವನ್ನು ನಮೂದಿಸಿ"; //Kannada
                }
                else if (language === "hi") {
                    messageBox.setAttribute("lang", "hi");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "अपना संदेश दर्ज करें"; // Hindi placeholder
                }
                else if (language === "mr") {
                    messageBox.setAttribute("lang", "mr");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "तुमचा संदेश प्रविष्ट करा"; // Marati placeholder
                }
                else if (language === "gu") {
                    messageBox.setAttribute("lang", "gu");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "તમારો સંદેશ દાખલ કરો"; // Gujarati placeholder
                }
                else if (language === "or"){
                    messageBox.setAttribute("lang", "or");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "ତୁମର ବାର୍ତ୍ତା"; // Odia placeholder
                }
                else if (language === "en") {
                    messageBox.setAttribute("lang", "en");
                    messageBox.setAttribute("dir", "ltr");
                    messageBox.placeholder = "Enter your message"; // English placeholder
                }
            }


            let buttonsDisabled = false;
            let offerAccepted = false;
            let userTotal = 0;
            let compTotal = 0;
            let offerValue = 0;
            let compClicks = 0;

            let userScores = [];
            let compScores = [];

            function userClick(index) {
                console.log('offerAccepted ' , offerAccepted);
                if (buttonsDisabled) return;
                if (offerAccepted) return;
                let button = document.getElementById('btn' + index);
                let value = parseInt(button.getAttribute('data-value'));
                handleButtonClick(index, value, 'User');
                userTotal += value;
                userScores.push(value);
                updateScoreTable();
                buttonsDisabled = true;
                setTimeout(() => {
                    autoClick();
                }, 1000);
            }

            function handleButtonClick(index, value, source) {
            console.log('inside handleButtonClick');
                let button = document.getElementById('btn' + index);
                if (source === "User"){
                    button.innerHTML = \`₹\${value}<br><span style="color: white;font-weight: bold;">\${source}</span>\`;
                }
                else{
                    button.innerHTML = \`₹\${value}<br><span style="color: blue;font-weight: bold;">\${source}</span>\`;
                }
                
                button.classList.add(value > 20000 ? 'green' : value > 0 ? 'orange' : 'red');
                button.classList.add('disabled');
                button.setAttribute('data-source', source);
            }

            function autoClick() {
                console.log('inside autoClick');
                let unclickedButtons = Array.from(document.querySelectorAll('.button:not(.disabled)'));
                if (unclickedButtons.length === 0) {
                    buttonsDisabled = false;
                    console.log('(unclickedButtons.length === 0) ');
                    return;
                }
                let randomButton = unclickedButtons[Math.floor(Math.random() * unclickedButtons.length)];
                let index = randomButton.id.replace('btn', '');
                let value = parseInt(randomButton.getAttribute('data-value'));
                handleButtonClick(index, value, 'Comp');
                compClicks += 1;
                compTotal += value;
                compScores.push(value);
                updateScoreTable();
                if (!offerAccepted){
                    calculateUnclickedSum();
                    setTimeout(() => {
                        buttonsDisabled = false;
                        checkRemainingButton();
                    }, 1000);                
                }

            }

            function checkRemainingButton() {
                let unclickedButtons = Array.from(document.querySelectorAll('.button:not(.disabled)'));
                if (unclickedButtons.length === 1) {
                    let lastButton = unclickedButtons[0];
                    let index = lastButton.id.replace('btn', '');
                    let value = parseInt(lastButton.getAttribute('data-value'));
                    lastButton.innerHTML = \`₹\${value}<br><span style="color: black;font-weight: bold;">Bank</span>\`; 
                    lastButton.classList.add(value > 20000 ? 'green' : value > 0 ? 'orange' : 'red');
                    lastButton.classList.add('disabled');
                    checkWinner();
                }
            }
            function updateScoreTable() {
               if (!offerAccepted){
                    userScores.forEach((val, i) => document.getElementById(\`user-score\${i+1}\`).innerText = '₹' + val.toLocaleString());
                    document.getElementById('user-total').innerText = '₹' + userTotal.toLocaleString();                                  
               }
                let userTotalCell = document.getElementById('user-total'); 
                compScores.forEach((val, i) => document.getElementById(\`comp-score\${i+1}\`).innerText = '₹' + val.toLocaleString());                
                document.getElementById('comp-total').innerText = '₹' + compTotal.toLocaleString();                
                let compTotalCell = document.getElementById('comp-total');
                compTotalCell.style.backgroundColor = compTotal < userTotal ? 'red' : 'green';
                userTotalCell.style.backgroundColor = userTotal < compTotal ? 'red' : 'green';
            }
            function calculateUnclickedSum() {
                let availableValues = [...document.querySelectorAll('.button:not(.disabled)')]
                    .map(button => parseInt(button.getAttribute('data-value')) || 0);
                let sum = availableValues.reduce((acc, val) => acc + val, 0) / 1.8;
                offerValue = Math.round(sum / 5000) * 5000;
                if (userTotal < compTotal){
                    offerValue = offerValue + Math.round((compTotal / 1.5) / 5000) * 5000;
                }
                if ((compTotal + offerValue) < userTotal){
                   offerValue = 0;
                }
                if (offerValue < 0){
                   offerValue = 0
                }
                if (compClicks === 4)
                {
                    offerValue = 0;
                }

                let button = document.getElementById('add-rounded-sum');
                if (offerValue !== 0) {
                    button.innerText = \`Offer to Quit ₹\${offerValue.toLocaleString()}\`;
                    button.style.display = 'block'; // Show the button
                    button.setAttribute('data-value', offerValue); // Store the offerValue in the button
                } else {
                    button.style.display = 'none'; // Hide if offerValue is 0
                }
                let button1 = document.getElementById('instruction');

            }

            function addofferValueToUserTotal() {
                let i  = 0;
                userTotal = userTotal + offerValue;
                offerAccepted = true;
                let button = document.getElementById('add-rounded-sum');
                userScores.push(offerValue);
                userScores.forEach((val, i) => document.getElementById(\`user-score\${i+1}\`).innerText = '₹' + val.toLocaleString());
                document.getElementById('user-total').innerText = '₹' + userTotal;
                console.log(userTotal);
                let userTotalCell = document.getElementById('user-total');
                let compTotalCell = document.getElementById('comp-total');
                compTotalCell.style.backgroundColor = compTotal < userTotal ? 'red' : 'green';
                userTotalCell.style.backgroundColor = userTotal < compTotal ? 'red' : 'green';
                button.style.display = 'none'; // Hide the button after adding the value
                console.log('compClicks ', compClicks);                
                for ( i = compClicks; i < 4; i++){
                    setTimeout(() => {autoClick();}, i*1000); 
                }
                setTimeout(() => {checkWinner();}, (5 - compClicks) * 1500); 
                
                                                
                
            }

            function disableUserButtons() {
                document.querySelectorAll('.button').forEach(button => {
                    button.classList.add('disabled');
                });
            }
            function checkWinner() {
               console.log('inside checkWinner');
                if (userTotal > compTotal) {
                    gameResult = "You Won";
                }
                else{
                     gameResult = "Its a Time-pass Game...";
                }
                document.getElementById('medal').innerText = gameResult;
                document.getElementById('medal').style.display = 'block';
                document.getElementById('reset').style.display = 'block';
            }
            function resetGame() {
                vscode.postMessage({ command: 'reset' });
            }
            function toggleInstructions() {
            const box = document.getElementById('instructions');
            box.style.display = (box.style.display === 'none' || box.style.display === '') ? 'block' : 'none';
            }
        </script>
    </body>
    </html>`;
}

async function registerUser(username: string): Promise<boolean> {
    try {
      const response = await fetch("https://raoh09sh65.execute-api.ap-south-1.amazonaws.com/prod/registeruser", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(
            { 
                "userid": username,
                "password": "",
                "username": "",
                "secquestion": "",
                "secanswer": ""
            }
        ),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      console.log(`User registered successfully: ${username}`);
      return true; // Successfully registered
    } catch (error) {
      console.error("Error registering user:", error);
      return false; // Registration failed
    }
  }


  async function showCodeSmell(context: vscode.ExtensionContext){

    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) {
        vscode.window.showInformationMessage('No workspace found!');
        return 0;
    }        
    const folderPath = workspaceFolders[0].uri.fsPath;

    await callAllFiles(context, folderPath);

    


}


async function callAllFiles(context: vscode.ExtensionContext, dirPath: string) {
    let totalLines = 0;

    processingStatus = "Processing Started...";
    vscode.window.showInformationMessage(processingStatus);
    tableRows = "";


    rulesets = getPMDOptions(context);
    if (rulesets.length < 1){
        tableRows = "";
        generateTableHtml_JCS(context, "");
        processingStatus = "No options selected";
        vscode.window.showInformationMessage(processingStatus);
        return;
    }

    // Recursively read the directory and its files
    const files = await readDir(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);

        // If it's a directory, call the function recursively
        const stat = fs.statSync(filePath);
        if (stat.isDirectory()) {
            await callAllFiles(context, filePath);
        } 
        else if (isCodeFile(filePath)) {
            await CheckCodeSmell(context, filePath);
        }
    }

}



async function CheckCodeSmell(context: vscode.ExtensionContext, filePath: string) {

    const pmdPath = 'pmd'; 


    let outputtext = "";
    let issues: string[] = [];
    const command = `${pmdPath} check -d ${filePath} -R ${rulesets} -f text`;
   // vscode.window.showInformationMessage(command);
        exec(command, (error, outputtext, stderr) => {
            if (error) {
                if (!stderr.includes ('[WARN]')) {
                vscode.window.showErrorMessage(`PMD execution failed: ${stderr}`);
                processingStatus = "Unable to process. Please check pmd guidelines.";
                vscode.window.showInformationMessage(processingStatus);
                }
            }
            if (outputtext.length > 0)
            {
              //  totalCodeSmell = totalCodeSmell + outputtext;
                totalCodeSmell = outputtext;
                processingStatus = "Processing Completed";        
                vscode.window.showInformationMessage(processingStatus);        
                if(totalCodeSmell.length > 0){

                    generateTableHtml_JCS(context, filePath);
                    const lines = totalCodeSmell.split('\n');
                    // Set the HTML content for the Webview

                }
                issues =  totalCodeSmell.split('\n');             
            }
            if (issues.length === 0) {
                processingStatus = "Processing Completed.";
                tableRows = "";
                generateTableHtml_JCS(context, "");
                vscode.window.showInformationMessage(processingStatus);
            } 
        });
            
 }

async function generateTableHtml_JCS(context: vscode.ExtensionContext, filepath: string) {
    const rows = (totalCodeSmell ?? "").trim().split('\n').map(line => line.split(/:+/)); // Splits by :
    tableRows = tableRows + rows.map(row => {
        let col1 = row.length > 0 ? row[0] : "";
        let col2 = row.length > 2 ? row[1] : "";
        let col3 = row.length > 2 ? row[2] : "";
        let col4 = row.length > 2 ? row[3] : "";
        let col5 = row.length > 2 ? row[4] : "";
        if((col1.length > 0) && (col5.length === 0))
        {
            col5 = col1;
            col1 = filepath;
        }

        return `<tr><td>${col1}${col2}</td><td>${col3}</td><td>${col5}</td></tr>`;
    }).join('');

    if (panel) {                        
        panel.reveal(vscode.ViewColumn.One);      
    } else {
        panel = vscode.window.createWebviewPanel('Code-Smell', 'Code-Smell', vscode.ViewColumn.One, { enableScripts: true });
    }
    panel.webview.html = getWebviewContent_JCS(context);
}

// Define checkboxes with corresponding values
const optionValues: { [key: string]: string } = {
    "Best Practices": "category/java/bestpractices.xml",
    "Code Style": "category/java/codestyle.xml",
    "Design": "category/java/design.xml",
    "Documentation": "category/java/documentation.xml",
    "Default": "rulesets/java/quickstart.xml",
    "Error Prone": "category/java/errorprone.xml",
    "Multithread":  "category/java/multithreading.xml",
    "Performance": "category/java/performance.xml",
    "Security": "category/java/security.xml"

};

function getPMDOptions(context: vscode.ExtensionContext): string {
    const workspaceState = context.workspaceState;
    savedSelections = workspaceState.get<string[]>('selectedOptions', []);
    const selectedWithValues = savedSelections.map((key: string) => `${optionValues[key] || 'Unknown Value'},`);

    checkboxHtml = Object.keys(optionValues).map(option => {
        const checked = (savedSelections || []).includes(option) ? 'checked' : '';
        return `<label><input type="checkbox" value="${option}" ${checked}> ${option}</label><br>`;
    }).join('');

    return selectedWithValues.join('');
}

function getWebviewContent_JCS(context: vscode.ExtensionContext){
    return `<!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; padding: 10px; background-color: black; color: white; display: flex; }
            .left-panel, .right-panel { padding: 4px; }
            .left-panel { width: 15%; float: left; height: 73vh; border-right: 1px solid grey; display: flex; flex-direction: column; }
            .right-panel { width: 85%; position: relative; padding: 1px; display: flex; flex-direction: column; align-items: center; }
            .checkboxes { padding: 10px; }
            .checkbox-group { margin-bottom: 15px; }
            button { padding: 8px 15px; background: #007acc; color: white; border: none; cursor: pointer; }
            button:hover { background: #005f99; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid white; padding: 6px; text-align: left; }
            th { font-size: 20px; color: green; background-color: black; } /* Yellow text on black background */
        </style>
    </head>
    <body>
        <div class="left-panel">
            <div class="checkboxes">
                <h3>Select Options:</h3>
                <div class="checkbox-group">${checkboxHtml}</div>
                <button onclick="invokeCodeSmellCheck()">Analyse Code</button>
            </div>
        </div>
        <div class="right-panel">
                <h3>Code Smell Analysis</h3>
                <table>
                <tr><th>${tableheader}</th></tr>
                ${tableRows}
                </table>
        </div>

        <script>
            const vscode = acquireVsCodeApi();
            function invokeCodeSmellCheck(){
                const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
                const selectedValues = Array.from(checkboxes).map(cb => cb.value);
                vscode.postMessage({ command: 'run', selected: selectedValues});
            }
        </script>
    </body>
    </html>`;
}

/*
async function readDir(dirPath: string): Promise<string[]> {
    return new Promise((resolve, reject) => {
        fs.readdir(dirPath, (err, files) => {
            if (err) {
                reject(err);
            } else {
                resolve(files);
            }
        });
    });
}
    */

function isCodeFile(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return ['.js', '.ts', '.html', '.css', '.cpp', '.java', '.py', '.dart', '.c'].includes(ext);
}


interface CompilationDetails {
    lineCount: number;
    errorCount: number;
    errorAvg: number;
    compileDate: string;
    progress: string;
    newline: string;
}

async function generateTableHtml(context: vscode.ExtensionContext) {

    const rows = (analysedData_CE ?? "").trim().split('\n').map(line => line.split(/,+/)); // Splits by :
    tableRows_CE = tableRows_CE + rows.map(row => {
        let col1 = row.length > 0 ? row[0] : "";
        let col2 = row.length > 2 ? row[1] : "";
        let col3 = row.length > 2 ? row[2] : "";
        let col4 = row.length > 2 ? row[3] : "";
        let col5 = row.length > 2 ? row[4] : "";
        let col6 = row.length > 2 ? row[5] : "";
        return `<tr><td>${col4} ${col5}</td><td>${col1}</td><td>${col2}</td><td>${col3}</td><td>${col6}</td></tr>`;
    }).join('');

  //  panel_CE.webview.html = getWebviewContent_CE(context);
}

async function storeCompilationDetails(context: vscode.ExtensionContext): Promise<number> {
    let storedData: CompilationDetails[] = context.workspaceState.get<CompilationDetails[]>('compilationData', []) || [];

    if (!Array.isArray(storedData)) {
        context.workspaceState.update('compilationData', []); // Initialize as an empty array if undefined or incorrect type
    }

	const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showInformationMessage('No workspace found!');
            return 0;
        }

        const folderPath = workspaceFolders[0].uri.fsPath;

        const lineCount = await countLinesOfCode(folderPath);

        // Step 2: Count compilation errors in the workspace
        const errorCount = countCompilationErrors();
        let progress = "";

        if(errorCount !== -1){

            let errorAvg = (errorCount/lineCount) * 100;
            errorAvg = parseFloat(errorAvg.toFixed(2));

            // Step 3: Get the current date and time of compilation
            const compileDate = new Date().toLocaleString();

            if (storedData.length > 0){
                if (Number(JSON.stringify(storedData[0].errorAvg)) > errorAvg){
                    progress = "👍";
                }
                else if (Number(JSON.stringify(storedData[0].errorAvg)) === errorAvg){
                    progress = "👍=👍";
                }
                else{
                    progress = "👎";
                }
            }
            else{
                progress = "😊";
            }

            if (lineCount > 0) {
                // Step 4: Create the new compilation data entry
                const newCompilationData: CompilationDetails = {
                    lineCount,
                    errorCount,
                    errorAvg,
                    compileDate,
                    progress,
                    newline: "\n"
                };
    

                if (storedData.length > 19) {
                    storedData.pop(); // Remove the first (oldest) entry if we have more than 20
                }
                // Step 5: Add the new entry to the stored data (keeping only the last 20 entries)
                // Push new value to the front of the array (stack behavior)
                context.workspaceState.update('compilationData', []); 
                await context.workspaceState.update('compilationData', undefined);
                await context.workspaceState.update('storedSelections', undefined);
                await context.workspaceState.update('lastSaved', undefined);
                storedData.unshift(newCompilationData);
               // vscode.window.showInformationMessage(JSON.stringify(storedData));
    
                // Store the updated compilation data back into workspaceState
                context.workspaceState.update('compilationData', storedData);
            }   
   
        }
        else {
            vscode.window.showInformationMessage(`Vscode is Busy. Please rerun after vscode is ready`);
        }

        return storedData.length;

}

async function displayCompilationHistory(context: vscode.ExtensionContext) {


    const storedCompilationData = context.workspaceState.get<CompilationDetails[]>('compilationData', []);
    if (storedCompilationData.length === 0) {
        vscode.window.showInformationMessage('No compilation data available.');
        return;
    }

    
    // Show the last 20 compilation details (or all if fewer than 20)
    let detailsMessage = storedCompilationData
        .map((data, index) => `${data.lineCount}, ${data.errorCount}, ${data.errorAvg}, ${data.compileDate}, ${data.progress}, ${data.newline}`)
        .join("\n");
    
    tableRows_CE = "";
    analysedData_CE = detailsMessage;
    generateTableHtml(context);

   // vscode.window.showInformationMessage(`Last Compilation Details:\n${detailsMessage}`);

    // Create a new Webview panel_CE
    if (panel_CE) {
        panel_CE.reveal(vscode.ViewColumn.One);       
    }
    else{
        panel_CE = vscode.window.createWebviewPanel(
            'Compilation-Errors', 'Compilation-Errors', vscode.ViewColumn.One, { enableScripts: true });
    }

    // Set the HTML content for the Webview
    panel_CE.webview.html = getWebviewContent_CE(detailsMessage);

    // Optionally, you can listen to Webview events, like on close or on message
         // Handle webview disposal (when closed)
         panel_CE.onDidDispose(() => {
            panel_CE = undefined; // Reset the reference
        }, null, context.subscriptions);
    /*
    vscode.window.showInformationMessage(`Last Compilation Details:\n${detailsMessage}`, 'OK').then((selection) => {
        if (selection === 'OK') {
            // The "OK" button was clicked, the message will be closed automatically
            console.log("OK button clicked");
        }
    });
    */


}


// Function to count the compilation errors in the workspace
function countCompilationErrors(): number {

    let diagnostics: [vscode.Uri, vscode.Diagnostic[]][] = [];
    // Listen for when an editor becomes active and then check diagnostics


    //    if (vscode.window.activeTextEditor) {
           diagnostics = vscode.languages.getDiagnostics();   
           if(diagnostics.length > 0){
                let errorCount = 0;
               // vscode.window.showInformationMessage(JSON.stringify(diagnostics));
    
                // Loop through each diagnostic collection and count errors       
                diagnostics.forEach(([uri, diagnosticArray]) => {
                    diagnosticArray.forEach((diagnostic) => {
                        if (diagnostic.severity === vscode.DiagnosticSeverity.Error) {
                            errorCount++;
                        }
                    });
                });  
                return errorCount;   
           }
    
    //    }




    return -1;
}

async function countLinesOfCode(dirPath: string): Promise<number> {
    let totalLines = 0;

    // Recursively read the directory and its files
    const files = await readDir(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);

        // If it's a directory, call the function recursively
        const stat = fs.statSync(filePath);
        if (stat.isDirectory()) {
            totalLines += await countLinesOfCode(filePath);
        } else if (isCodeFile_CE(filePath)) {
            totalLines += await countLinesInFile_CE(filePath);
        }
    }

    return totalLines;
}

async function readDir(dirPath: string): Promise<string[]> {
    return new Promise((resolve, reject) => {
        fs.readdir(dirPath, (err, files) => {
            if (err) {
                reject(err);
            } else {
                resolve(files);
            }
        });
    });
}

function isCodeFile_CE(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return ['.js', '.ts', '.html', '.css', '.cpp', '.java', '.py', '.dart', '.c'].includes(ext);
}

async function countLinesInFile_CE(filePath: string): Promise<number> {
    return new Promise((resolve, reject) => {
        let lines = 0;
        const stream = fs.createReadStream(filePath, 'utf8');
        
        stream.on('data', (chunk) => {
            lines += chunk.toString('utf8').split('\n').length;
        });

        stream.on('end', () => {
            resolve(lines);
        });

        stream.on('error', (err) => {
            reject(err);
        });
    });
}


// Function to return the HTML content for the Webview
function getWebviewContent_CE(detailsMessage: string): string {
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Current Date</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 10px; background-color: black; color: white; display: flex; }
            .panel_CE { width: 100%; position: relative; padding: 1px; display: flex; flex-direction: column; align-items: center; }
            .date {
                font-size: 24px;
                font-weight: bold;
            }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid white; padding: 4px; text-align: center; }
            td { font-size: 16px; }
            th { font-size: 18px; color: green; background-color: black; } /* Yellow text on black background */
        </style>
    </head>
    <body>
        <div class="panel_CE">   
            <h1>Compilation History</h1><br>
            <table>
            <tr><th>${tableheader_CE}</th></tr>
            ${tableRows_CE}
            </table>
        </div>

    </body>
    </html>
    `;
}



export function getWebviewContent_GT(images: { id: string; thumbnail: string; full: string }[], receiverIds: string[], receivedMessages: { imageId: string; senderId: string; dateReceived: string; message: string }[]) {
	const thumbnailsHtml = images.map((img, index) => `
	  <label class="thumb-option">
		<input type="radio" name="thumbnail" value="${img.id}" data-full="${img.full}" ${index === 0 ? 'checked' : ''} />
		<img src="${img.thumbnail}" alt="Thumbnail ${index + 1}" />
	  </label>
	`).join('');
  
	const dropdownHtml = receiverIds.map(id => `
	  <option value="${id}">${id}</option>
	`).join('');
  
	  let rightPanelContent = '';

	  if (receivedMessages.length === 0) {
		rightPanelContent = `<p style="color: gray; padding: 10px;">No Cards Received Yet.</p>`;
	  } else {
		let sortedMessageIds = Array.from(receivedMessages).sort((a, b) => b.dateReceived.localeCompare(a.dateReceived));
		receivedMessages = sortedMessageIds;
		const listHtml = receivedMessages.map((msg, idx) => `
		<label style="display: flex; align-items: center; margin-bottom: 6px;">
		  <input 
			type="radio" 
			name="rightImage" 
			value="${msg.imageId}" 
			data-message="${msg.message || ''}"
			${idx === 0 ? 'checked' : ''} 
		  />
		  <span style="margin-left: 8px;">
			${msg.senderId} - ${msg.dateReceived}
		  </span>
		</label>
	  `).join('');
	  
	  
		const firstImageId = receivedMessages[0].imageId;
		const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
		const ext = '.jpg'; // or your actual extension
		const firstImageUrl = `${s3Base}${firstImageId}`;
	  
		rightPanelContent = `
		  <div class="right-scrollable-list">${listHtml}</div>
		  <img id="rightFullImage" src="${firstImageUrl}" alt="Selected Full Image" />
		        <div class="card">
					<div class="emoji">🎉</div>
					<div id="rightImageMessage" style="color: #797bd9; font-size: 16px; font-weight: bold; justify-content: center;"> </div>
				</div>
		  
		`;
	  }
	  
  
	const firstFullImage = images.length > 0 ? images[0].full : '';
  
	return `
	  <!DOCTYPE html>
	  <html lang="en">
	  <head>
		<style>
		  body {
			font-family: sans-serif;
			margin: 0;
			padding: 0;
			display: flex;
			height: 100vh;
			overflow: hidden;
		  }
  
		  .left-panel, .right-panel {
			padding: 16px;
			overflow-y: auto;
		  }
  
		  .left-panel {
			width: 38%;
			border-right: 1px solid #ccc;
		  }
  
		  .right-panel {
		  	position: relative;
			width: 62%;
			display: flex;
			flex-direction: column;
		  }
  
		  h2 {
			margin-top: 0;
		  }
  
		  .thumb-scroll-container {
			display: flex;
			overflow-x: auto;
			gap: 10px;
			padding-bottom: 12px;
			margin-bottom: 16px;
			border-bottom: 1px solid #ddd;
		  }
  
		  .thumb-option {
			display: flex;
			flex-direction: column;
			align-items: center;
			cursor: pointer;
		  }
  
		  .thumb-option img {
			width: 100px;
			height: 60px;
			object-fit: contain;
			border: 2px solid transparent;
			border-radius: 6px;
		  }
  
		  .thumb-option input:checked + img {
			border-color: #007acc;
		  }
  
		  #fullImage {
			width: 95%;
			height: 300px;
			object-fit: contain;
			margin-left: 6px;
			border-radius: 6px;
			background-color: #f0f0f0;
			margin-bottom: 12px;
			display: block;
		  }
  
		  .form-section {
			display: flex;
			flex-direction: column;
			align-items: flex-start;
			gap: 12px;
		  }
  
		  #message {
			width: 89%;
			padding: 10px;
			font-size: 14px;
			margin-left: 6px;
			border: 1px solid #ccc;
			border-radius: 4px;
			transition: border-color 0.3s;
		  }
  
		  #message:focus {
			border-color: #007acc;
			outline: none;
		  }
  
		  .bottom-row {
			display: flex;
			gap: 10px;
			margin-left: 14px;
			width: 90%;
		  }
  
		  select {
			flex: 1;
			padding: 8px;
			font-size: 14px;
			border: 1px solid #ccc;
			border-radius: 4px;
			transition: border-color 0.3s;
		  }
  
		  select:focus {
			border-color: #007acc;
			outline: none;
		  }
  
		  button {
			min-width: 85px;
			padding: 8px 12px;
			font-size: 14px;
			border: none;
			border-radius: 4px;
			background-color: #ccc;
			color: #fff;
			cursor: not-allowed;
			transition: background-color 0.3s;
		  }
  
		  button:enabled {
			background-color: #007acc;
			cursor: pointer;
		  }
  
		  .right-scrollable-list {
			max-height: 100px;
			overflow-y: auto;
			border: 1px solid  #444;
			padding: 8px;
			border-radius: 6px;
			margin-bottom: 16px;
			background-color: #222;
		  }

		  #fullImage {
			max-width: 100%;
			height: 300px;
			object-fit: fill;
			background-color: #222;
			border-radius: 6px;
		  }

		  #rightFullImage {
			max-width: 100%;
			height: 400px;
			object-fit: fill;
			background-color: #222;
			border-radius: 6px;
		  }
		.points-display {
		background:rgb(151, 146, 140);
		position: absolute;
		top: 10px;
		right: 16px;
		font-size: 18px;
		padding: 10px;
		font-weight: bold;
		/* Additional styling as needed */
		}
		.card {
          background: #F1ECE5;
		  margin-top: 6px;
          border-radius: 6px;
          box-shadow: 0 8px 16px rgba(0,0,0,0.2);
          padding: 40px;
          max-width: 700px;
          text-align: center;
        }
        .card .emoji {
          font-size: 32px;
          margin-bottom: 6px;
        }
		</style>
	  </head>
	  <body>
		<div class="left-panel">
		  <h2>Select a Greeting Card</h2>
  
		  <div class="thumb-scroll-container">
			${thumbnailsHtml}
		  </div>
  
		  <img id="fullImage" src="${firstFullImage}" alt="Full Image Preview" />
  
		  <div class="form-section">
			<textarea id="message" rows="3" placeholder="Enter your message..."></textarea>
			<div class="bottom-row">
			  <select id="receiver">
				<option value="">-- Select Receiver --</option>
				${dropdownHtml}
			  </select>
			  <button id="sendButton" disabled>Send</button>
			</div>
		  </div>
		</div>
  

  
		<div class="right-panel">
		<div class="points-display" id="pointsDisplay" style="color:rgb(98, 7, 63);"></div>
		<h2>Appreciations received</h2>
		${rightPanelContent}
		</div>

		<script>
		  const fullImage = document.getElementById('fullImage');
		  const sendButton = document.getElementById('sendButton');
		  const receiverInput = document.getElementById('receiver');
		  const messageInput = document.getElementById('message');
		  const rightFullImage = document.getElementById('rightFullImage');
		  const rightImageMessage = document.getElementById('rightImageMessage');
		  let selectedImageId = document.querySelector('input[name="thumbnail"]:checked')?.value;
		  console.log("UserName: " , '${senderId}');

			const apiUrl = 'https://ds5mcukui7.execute-api.ap-south-1.amazonaws.com/SayThanksProd/getThanksPoints'; // Replace with your API endpoint

			fetch(apiUrl, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({ "userid": '${senderId}' }),
			})
			.then(response => {
				if (!response.ok) {
				throw new Error('Network response was not ok');
				}
				return response.json();
			})
			.then(data => {
			   let totalPoints = 0;
			   const body = JSON.parse(data.body);

				if (!data.body) {
					throw new Error('Invalid response from API');
				}
				else {
					totalPoints = body.totalPoints;
				}

				displayPoints(totalPoints);
			})
			.catch(error => {
				console.error('There was a problem with the fetch operation:', error);
			});

			function displayPoints(points) {
			const pointsDisplay = document.getElementById('pointsDisplay');
			pointsDisplay.textContent = \`Points Earned: \${points}\`;
			}

  
			// Set initial right panel full image on load
			(function initRightPanelImageAndMessage() {
			const firstRightRadio = document.querySelector('input[name="rightImage"]:checked');
			if (firstRightRadio) {
				const id = firstRightRadio.value;
				const msg = firstRightRadio.dataset.message;
				const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
				const ext = '.jpg';

				rightFullImage.src = s3Base + id;
				const formattedMessage = msg.replace(/\\n/g, \'<br>\');
				rightImageMessage.innerHTML = formattedMessage;
			}
			})();


		  document.querySelectorAll('input[name="thumbnail"]').forEach(radio => {
			radio.addEventListener('change', (e) => {
			  selectedImageId = e.target.value;
			  const fullUrl = e.target.getAttribute('data-full');
			  fullImage.src = fullUrl;
			  fullImage.style.display = 'block';
			  validateInputs();
			});
		  });
  
			document.querySelectorAll('input[name="rightImage"]').forEach(radio => {
				radio.addEventListener('change', (e) => {
					const id = e.target.value;
					const msg = e.target.dataset.message;
					const s3Base = 'https://animateinput.s3.ap-south-1.amazonaws.com/';
					const ext = '.jpg'; //only jpg supported for now

					rightFullImage.src = s3Base + id;
					const formattedMessage = msg.replace(/\\n/g, \'<br>\');
					rightImageMessage.innerHTML = formattedMessage;
				});
			});
  
		  receiverInput.addEventListener('change', validateInputs);
		  messageInput.addEventListener('input', validateInputs);
  
		  function validateInputs() {
			const message = messageInput.value.trim();
			const receiver = receiverInput.value;
			const enable = selectedImageId && message && receiver;
			sendButton.disabled = !enable;
		  }
  
		  sendButton.addEventListener('click', async () => {
			const message = messageInput.value.trim();
			const receiverId = receiverInput.value;
  
			if (!selectedImageId || !receiverId || !message) return;
  
			const payload = {
			  senderId: '${senderId}',
			  imageId: selectedImageId,
			  receiverId: receiverId,
			  message: message
			};
  
			sendButton.disabled = true;
  
			try {
			  const response = await fetch('https://2zisqo65p2.execute-api.ap-south-1.amazonaws.com/SayThanksProd/updateThanks', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(payload)
			  });
  
			  if (response.ok) {
				alert('Greeting card sent successfully!');
				messageInput.value = '';
				receiverInput.value = '';
				validateInputs();
			  } else {
				alert('Failed to send greeting card.');
				sendButton.disabled = false;
			  }
			} catch (err) {
			  console.error(err);
			  alert('Error sending greeting card.');
			  sendButton.disabled = false;
			}
		  });
  
		  // Initial validation
		  validateInputs();
		</script>
	  </body>
	  </html>
	`;
  }

  async function fetchAllReceivers() {

    const getAllUsersApiURL = "https://w0jnm95oyc.execute-api.ap-south-1.amazonaws.com/animal/userlist";
    const jsonBody = {};

    try {
        const response = await fetch(getAllUsersApiURL, {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=UTF-8" },
            body: JSON.stringify(jsonBody)
        });
        
        const result = await response.json() as { body?: string };

        
        
        if (result.body) {
            const parsedBody = JSON.parse(result.body);
            if (Array.isArray(parsedBody)) {
                receiverIds = parsedBody.map(item => item.userid).filter(id => id);
				const index = receiverIds.indexOf(senderId!);
				if (index > -1) {
					receiverIds.splice(index, 1); // Remove the senderId from the list	
				}
            }
        }

    } catch (error) {
        const errorMessage = (error as any).message || "Unknown error";
        vscode.window.showErrorMessage("API request failed: " + errorMessage);
    }
}
  
async function getGreetingCount()
{
    const url = "https://animateinput.s3.ap-south-1.amazonaws.com/greetingcount.txt";

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const text = await response.text();
        const numberMatch = text.match(/\d+/); // Extract first number from file

        if (numberMatch) {
            totalGreetings = parseInt(numberMatch[0], 10);
        } else {
            totalGreetings = 0;
        }
    } catch (error: any) {
        vscode.window.showErrorMessage(`Error fetching file: ${error.message}`);
        totalGreetings = 0;
    }
}

function deactivate() {}

module.exports = { activate, deactivate };
