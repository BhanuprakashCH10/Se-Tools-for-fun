# apicall README

This is the README for extension "se_extension". 

### Release 0.0.6

Purpose: 1. Take a small break to connect with friends and relax for better productivity. 2. Appreciate Your Team Members